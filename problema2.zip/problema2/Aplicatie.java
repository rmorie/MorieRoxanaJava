package problema2;

import java.util.ArrayList;
import java.util.List;

public class Aplicatie {

	public static void main(String[] args) {
		List <Persoana> pers = new ArrayList<>();

	}

}
